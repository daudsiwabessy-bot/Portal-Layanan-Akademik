# Portal Layanan Akademik

Tugas Pertemuan 5: Responsive & Accessible Web Client.
Halaman statis (HTML + CSS, tanpa JavaScript).

- **Demo:** https://USERNAME.github.io/NAMA-REPO/
- **Source:** https://github.com/USERNAME/NAMA-REPO

## Cara menjalankan
Buka `index.html` di browser. Tidak perlu XAMPP atau server lokal.

## Keputusan desain
- Mobile-first: satu kolom, lalu 2 kolom di 40rem dan 4 kolom di 64rem (dipilih saat kartu mulai renggang).
- Landmark: header, nav, main, section/article, footer; heading h1 > h2 > h3 berurutan.
- Form: label terasosiasi (`for`/`id`), `required`, `type="email"`, `pattern` NIM, `minlength`/`maxlength`, fieldset+legend untuk radio.
- Aksesibilitas: skip link, fokus terlihat (outline 3px), target sentuh minimal 44px, native element sebelum ARIA.
- Gambar: tidak memakai gambar raster. SVG logo di header **dekoratif** (`aria-hidden="true"`) karena nama portal sudah ada sebagai teks. SVG alur di intro **informatif** (`role="img"` + `<title>`/`<desc>`).

## Hasil pemeriksaan DevTools (isi setelah menguji)
| Pemeriksaan | Hasil | Bukti |
|---|---|---|
| Responsive 360 px | | evidence/360.png |
| Responsive 768 px | | evidence/768.png |
| Responsive 1280 px | | evidence/1280.png |
| Tanpa horizontal scroll | | |
| Network (reload, tidak ada resource gagal) | | evidence/network.png |
| Accessibility tree / Lighthouse | | evidence/a11y.png |
| Navigasi keyboard (Tab) | | evidence/focus.png |
| Validasi email salah | | evidence/validasi.png |

## Temuan debugging
(Tulis 2–3 temuan nyata, misalnya: apa yang kamu perbaiki setelah menguji, dan bagaimana caranya.)
